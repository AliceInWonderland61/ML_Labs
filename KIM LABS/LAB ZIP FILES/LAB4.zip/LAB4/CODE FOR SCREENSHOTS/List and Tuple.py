a=[1,2,3,4,5]
b=a[2]
print(b)
a.append(6)
print(a)
a[2]=7
print(a)

a=(1,2,3)
b=a[2]
print(b)
a1,a2,a3=a
print(a1,a2,a3)