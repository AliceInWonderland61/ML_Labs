a=7
if a<12:
    print("Good morning!")
elif a<17:
    print("Good afternoon!")
elif a<21:
    print("Good evening!")
else:
    print("Good night!")