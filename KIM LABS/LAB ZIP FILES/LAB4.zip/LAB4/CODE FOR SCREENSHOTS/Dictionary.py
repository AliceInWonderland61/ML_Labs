a={"Apple":3, "Pineapple":4}
print(a["Apple"])
a["Pineapple"]=7
print(a["Pineapple"])

a["Melon"]=3
print(a)