a=3; b=4
c=a+b
print(c)

d=a<b
print(d)

e= 3<4 and 4<5
print(e)

a= "Hello" + "Alissen D. Moreno"
print(a)
b=[1,2,3] + [4,5,6]
print(b)