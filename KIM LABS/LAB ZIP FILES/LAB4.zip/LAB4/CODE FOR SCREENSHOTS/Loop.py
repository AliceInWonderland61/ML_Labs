for i in [4,7,10]:
    print(i)
for i in range(3):
    print(i)
a=0
while a<3:
    print(a)
    a+=1