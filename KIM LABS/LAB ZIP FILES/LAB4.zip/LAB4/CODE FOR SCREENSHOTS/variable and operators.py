a=123
b=123.456
c="Hello, Alissen D. Moreno"
d=True
e=False
f=[1,2,3]
g=1.2e5
h=1.2e-5

print (a)
print (type(a))
print(d+e)