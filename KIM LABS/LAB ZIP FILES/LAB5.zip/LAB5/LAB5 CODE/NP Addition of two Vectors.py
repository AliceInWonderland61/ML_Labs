import numpy as np
a=np.array([0,1,2,3])
b=np.array([2,3,1,3])
print(a+b)