import numpy as np

a=np.array([0,1,2,3,4]) #1D array
print(a)
b=np.array([[0,1,2], [3,4,5]]) #2D array
print(b)
c=np.array([[[0,1],[2,3]],[[4,5],[6,7]]]) #3D array
print(c)
